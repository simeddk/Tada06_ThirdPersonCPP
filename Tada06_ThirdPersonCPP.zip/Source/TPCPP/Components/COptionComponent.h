#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "COptionComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class TPCPP_API UCOptionComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UCOptionComponent();


protected:
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Option")
	float MouseXSpeed;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Option")
	float MouseYSpeed;
};
