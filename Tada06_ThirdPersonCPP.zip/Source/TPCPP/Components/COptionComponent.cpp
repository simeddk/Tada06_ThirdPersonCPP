#include "COptionComponent.h"

UCOptionComponent::UCOptionComponent()
{
	MouseXSpeed = 90.f;
	MouseYSpeed = 90.f;
}
